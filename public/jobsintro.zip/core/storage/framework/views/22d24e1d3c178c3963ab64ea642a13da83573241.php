<div>
    <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li class="<?php echo e($notification->read_at == null ? "not-read" : ''); ?>" key=<?php echo e($loop->index); ?>>
            <a href="#" wire:click="readNotification(<?php echo e($notification); ?>)" >
                <div class="drop_avatar">
                    <img src="<?php echo e(asset($notification->notificationBy->avtar)); ?>" alt="">
                </div>
                <span class="drop_icon bg-gradient-primary">
                    <i class="icon-feather-thumbs-up"></i>
                </span>
                <div class="drop_text">
                    <p>
                    <strong><?php echo e($notification->notificationBy->firstname." ".$notification->notificationBy->lastname); ?></strong> <?php echo e($notification->data['info']); ?>

                    
                    </p>
                    <time><?php echo e($notification->created_at->diffForHumans()); ?> </time>
                </div>
            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        No Notifications to show 
    <?php endif; ?>
    
    <script>
        document.addEventListener('livewire:load', function() {
            setInterval(() => {
                Livewire.emit('getNotifications')    
                console.log("comment added")
            }, 3000); 
        });
    </script>
</div>
<?php /**PATH D:\Take care\AAMGroup\jobsintroLaravel-main-2\resources\views/livewire/templates/basic/notification-items.blade.php ENDPATH**/ ?>