
<?php $__env->startSection('content'); ?>
<div class="main_content">
    <div class="mcontainer">

        

        <div class="mb-6">
            <h2 class="text-2xl font-semibold"> <?php echo e($page_title); ?> </h2>
        </div>

        <div class="bg-white lg:divide-x lg:flex lg:shadow-md rounded-md shadow lg:rounded-xl overflow-hidden lg:m-0 -mx-4">
            <?php echo $__env->make($activeTemplate . 'partials.setting_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="lg:w-2/3">

                <div class="lg:flex lg:flex-col justify-between lg:h-full">

                    <!-- form header -->
                    <div class="lg:px-10 lg:py-8 p-6">
                        <h3 class="font-bold mb-2 text-xl"><?php echo e($page_title); ?></h3>
                    </div>

                    <!-- form body -->
                    
                </div>

            </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>
<script src="<?php echo e(asset($activeTemplateTrue . 'assets/js/checkpassword.js')); ?>"></script>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate . 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/qotq51m9rkvr/public_html/core/resources/views/templates/basic/user/settings/manage_sessions.blade.php ENDPATH**/ ?>