
<?php $__env->startSection('content'); ?>
<div class="main_content">
    <div class="mcontainer">

        

        <div class="mb-6">
            <h2 class="text-2xl font-semibold"> <?php echo e($page_title); ?> </h2>
        </div>

        <div class="bg-white lg:divide-x lg:flex lg:shadow-md rounded-md shadow lg:rounded-xl overflow-hidden lg:m-0 -mx-4">
            <?php echo $__env->make($activeTemplate . 'partials.setting_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="lg:w-2/3">

                <div class="lg:flex lg:flex-col justify-between lg:h-full">

                    <!-- form header -->
                    <div class="lg:px-10 lg:py-8 p-6">
                        <h3 class="font-bold mb-2 text-xl"><?php echo e($page_title); ?></h3>
                    </div>

                    <!-- form body -->
                    <form action="<?php echo e(route('user.setting.socialinks.update')); ?>" method="post" id="password_validate">
                        <?php echo csrf_field(); ?>
                        <div class="lg:py-8 lg:px-20 flex-1 space-y-4 p-6">

                            <div class="line">
                                <input class="line__input" id="facebook" autocomplete="off" name="facebook" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="Username" value="<?php echo e($user->facebook); ?>">
                                <span for="facebook" class="line__placeholder"><?php echo app('translator')->get('Facebook'); ?></span>
                            </div>

                            <div class="line">
                                <input class="line__input" id="twitter" autocomplete="off" name="twitter" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="Username" value="<?php echo e($user->twitter); ?>">
                                <span for="twitter" class="line__placeholder"><?php echo app('translator')->get('Twitter'); ?></span>
                            </div>

                            <div class="line">
                                <input class="line__input" id="vk" autocomplete="off" name="vk" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="Username" value="<?php echo e($user->vk); ?>">
                                <span for="vk" class="line__placeholder"><?php echo app('translator')->get('Vkontakte'); ?></span>
                            </div>

                            <div class="line">
                                <input class="line__input" id="linkedin" autocomplete="off" name="linkedin" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="Username" value="<?php echo e($user->linkedin); ?>">
                                <span for="linkedin" class="line__placeholder"><?php echo app('translator')->get('Linkedin'); ?></span>
                            </div>

                            <div class="line">
                                <input class="line__input" id="instagram" autocomplete="off" name="instagram" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="Username" value="<?php echo e($user->instagram); ?>">
                                <span for="instagram" class="line__placeholder"><?php echo app('translator')->get('Instagram'); ?></span>
                            </div>

                            <div class="line">
                                <input class="line__input" id="youtube" autocomplete="off" name="youtube" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="Username" value="<?php echo e($user->youtube); ?>">
                                <span for="youtube" class="line__placeholder"><?php echo app('translator')->get('YouTube'); ?></span>
                            </div>

                        </div>
                    </form>
                </div>

            </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>
<script src="<?php echo e(asset($activeTemplateTrue . 'assets/js/checkpassword.js')); ?>"></script>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate . 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/qotq51m9rkvr/public_html/core/resources/views/templates/basic/user/settings/socialinks.blade.php ENDPATH**/ ?>