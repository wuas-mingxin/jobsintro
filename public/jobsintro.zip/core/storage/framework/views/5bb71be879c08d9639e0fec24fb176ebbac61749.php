<div>
   <!-- Craete post modal -->
    <div id="create-post-modal" class="create-post is-story" uk-modal>
        <form wire:submit.prevent="save">
            <div id="model_create_post"
                class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical rounded-lg p-0 lg:w-5/12 relative shadow-2xl uk-animation-slide-bottom-small">

                <div class="text-center py-3 border-b">
                    <h3 class="text-lg font-semibold"> Create Post </h3>
                    <button class="uk-modal-close-default bg-gray-100 rounded-full p-2.5 right-2" type="button" uk-close uk-tooltip="title: Close ; pos: bottom ;offset:7"></button>
                </div>
                
                <div class="flex flex-1 items-start space-x-4 p-5">
                    <img src="<?php echo e(asset(auth()->user()->avtar)); ?>"
                        class="bg-gray-200 border border-white rounded-full w-11 h-11">
                    <div class="flex-1 pt-2">
                        <textarea wire:model.debounce.500ms="post_text" id="post_text" class="uk-textare text-white shadow-none focus:shadow-none text-xl font-medium resize-none" rows="5"
                            placeholder="What's Your Mind ? <?php echo e(auth()->user()->firstname); ?>!"> </textarea>
                    </div>

                </div>
                <div class="bsolute bottom-0 p-4 space-x-4 w-full">
                    <div class="flex bg-gray-50 border border-purple-100 rounded-2xl p-2 shadow-sm items-center">
                        <div class="lg:block hidden ml-1"> Add to your post </div>
                        <div class="flex flex-1 items-center lg:justify-end justify-center space-x-2">
                            <div class="image-upload">
                                <label for="file-input">
                                    <svg class="bg-blue-100 h-9 p-1.5 rounded-full text-blue-600 w-9 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                </label>
                                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input id="file-input"  wire:model="photo" type="file" style="display:none" />
                            </div>
                            <!-- view more -->
                            <svg class="hover:bg-gray-200 h-9 p-1.5 rounded-full w-9 cursor-pointer" id="veiw-more" uk-toggle="target: #veiw-more; animation: uk-animation-fade" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"> </path></svg>

                        </div>
                    </div>
                </div>
                <div class="flex items-center w-full justify-between border-t p-3">

                    <select class="selectpicker mt-2 story">
                        <option>Only me</option>
                        <option>Every one</option>
                        <option>People I Follow </option>
                        <option>People Follow Me</option>
                    </select>

                    <div class="flex space-x-2">
                        <a href="#" class="bg-red-100 flex font-medium h-9 items-center justify-center px-5 rounded-md text-red-600 text-sm">
                            <svg class="h-5 pr-1 rounded-full text-red-500 w-6 fill-current" id="veiw-more" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="false" style=""> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                            Live </a>
                        <button type="submit" class="bg-blue-600 flex h-9 items-center justify-center rounded-md text-white px-5 font-medium">
                        Share </button>
                    </div>

                    <a href="#" hidden
                        class="bg-blue-600 flex h-9 items-center justify-center rounded-lg text-white px-12 font-semibold">
                        Share 
                    </a>

                </div>
            </div>
        </form>
    </div>
    <style>
    .uk-modal-footer{
        color:black;
    }
    </style>
<script>
    window.addEventListener('closeModal', event => {
        document.getElementById("post_text").value = "";
        UIkit.modal('#create-post-modal').toggle();
        UIkit.modal.alert('Post Created Successfully');
    })
    
    window.addEventListener('sharedPost', event => {

        iziToast.show({
            title: 'Create Post',
            message: 'Post Created Successfully',
            position: 'topRight',
            color: 'green',
        });
        
    })
</script>
<div><?php /**PATH C:\Users\zeesh\Desktop\jobsintroLaravel-main-2\resources\views/livewire/template/basic/create-post.blade.php ENDPATH**/ ?>