<meta name="title" Content="">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <!-- Apple Stuff -->
    <link rel="apple-touch-icon" href="">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="">
    <!-- Google / Search Engine Tags -->
    <meta itemprop="name" content="">
    <meta itemprop="description" content="">
    <meta itemprop="image" content="">
    <!-- Facebook Meta Tags -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="">
    <meta property="og:description" content="">
    <meta property="og:image" content=""/>
    <meta property="og:image:type" content="image/" />
    <meta property="og:image:width" content="" />
    <meta property="og:image:height" content="" />
    <meta property="og:url" content="">
    <!-- Twitter Meta Tags -->
    <meta name="twitter:card" content="summary_large_image"><?php /**PATH C:\Users\zeesh\Desktop\jobsintroLaravel-main\resources\views/partials/seo.blade.php ENDPATH**/ ?>