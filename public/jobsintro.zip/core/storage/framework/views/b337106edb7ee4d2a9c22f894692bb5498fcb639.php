
<?php $__env->startSection('content'); ?>
<div class="main_content">
    <div class="mcontainer">

        

        <div class="mb-6">
            <h2 class="text-2xl font-semibold"> <?php echo e($page_title); ?> </h2>
        </div>

        <div class="bg-white lg:divide-x lg:flex lg:shadow-md rounded-md shadow lg:rounded-xl overflow-hidden lg:m-0 -mx-4">
            <?php echo $__env->make($activeTemplate . 'partials.setting_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="lg:w-2/3">

                <div class="lg:flex lg:flex-col justify-between lg:h-full">

                    <!-- form header -->
                    <div class="lg:px-10 lg:py-8 p-6">
                        <h3 class="font-bold mb-2 text-xl"><?php echo e($page_title); ?></h3>
                    </div>

                    <!-- form body -->
                    <form action="<?php echo e(route('user.setting.generalSetting.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="lg:py-8 lg:px-20 flex-1 space-y-4 p-6">

                            <div class="line">
                                <input class="line__input" id="username" autocomplete="off" name="username" type="text" onkeyup="this.setAttribute('value', this.value);" value="<?php echo e($user->username); ?>">
                                <span for="username" class="line__placeholder"><?php echo app('translator')->get('Username'); ?></span>
                            </div>
                            <div class="line">
                                <input class="line__input" id="phone" autocomplete="off" name="phone" type="text" onkeyup="this.setAttribute('value', this.value);" value="<?php echo e($user->phone); ?>">
                                <span for="phone" class="line__placeholder"> <?php echo app('translator')->get('Phone'); ?> </span>
                            </div>
                            <div class="line">
                                <input class="line__input" id="email" autocomplete="off" name="email" type="text" onkeyup="this.setAttribute('value', this.value);" value="<?php echo e($user->email); ?>" disabled="">
                                <span for="email" class="line__placeholder"><?php echo app('translator')->get('Email'); ?> </span>
                            </div>
                            <div class="line">
                                <input class="line__input" id="birthday" autocomplete="off" name="birthday" type="date" onkeyup="this.setAttribute('value', this.value);" value="<?php echo e($user->birthday); ?>">
                                <span for="birthday" class="line__placeholder"><?php echo app('translator')->get('Birthday'); ?> </span>
                            </div>
                            <div>
                                <label for="country"> <?php echo app('translator')->get('Country'); ?> </label>
                                <select id="country" name="country"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->country == 0): ?> selected <?php endif; ?> ><?php echo app('translator')->get('Select One Country...'); ?></option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php if($user->country == $key ): ?> selected <?php endif; ?>><?php echo e(__($country->country)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div>
                                <label for="gender"> <?php echo app('translator')->get('Gender'); ?> </label>
                                <select id="gender" name="gender"  class="shadow-none selectpicker with-border ">
                                    <option value="1" <?php if($user->gender == 1): ?> selected <?php endif; ?> >Male</option>
                                    <option value="2" <?php if($user->gender == 2): ?> selected <?php endif; ?> >Female</option>
                                    <option value="3" <?php if($user->gender == 3): ?> selected <?php endif; ?> >Rather Not Say</option>
                                </select>
                            </div>
                            <div class="line">
                                <label>Verification</label>
                                        
                                <div class="flex justify-between items-center">
                                    <div>
                                        <h4> Verified</h4>
                                    </div>
                                    <div class="switches-list -mt-8 is-large">
                                        <div class="switch-container">
                                            <label class="switch">
                                                <input type="checkbox" name="verified" <?php if($user->verified == 1): ?> checked <?php endif; ?> >
                                                <span class="switch-button"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label for="member_type"> <?php echo app('translator')->get('Member Type'); ?> </label>
                                <select id="member_type" name="member_type"  class="shadow-none selectpicker with-border ">
                                    <option value="1" <?php if($user->gender == 1): ?> selected <?php endif; ?> >Free Member</option>
                                    <option value="2" <?php if($user->gender == 2): ?> selected <?php endif; ?> >Star Member</option>
                                    <option value="3" <?php if($user->gender == 3): ?> selected <?php endif; ?> >Hot Member</option>
                                    <option value="4" <?php if($user->gender == 4): ?> selected <?php endif; ?> >Ultima Member</option>
                                    <option value="5" <?php if($user->gender == 5): ?> selected <?php endif; ?> >VIP Member</option>
                                </select>
                            </div>
                            <div class="line">
                                <input class="line__input" id="wallet" autocomplete="off" name="wallet" type="date" onkeyup="this.setAttribute('value', this.value);" value="<?php echo e($user->wallet); ?>">
                                <span for="wallet" class="line__placeholder"><?php echo app('translator')->get('Wallet'); ?> </span>
                            </div>

                        </div>

                        <div class="bg-gray-10 p-6 pt-0 flex justify-end space-x-3">
                            <button class="p-2 px-4 rounded bg-gray-50 text-red-500"> <?php echo app('translator')->get('Cancel'); ?> </button>
                            <button type="submit" class="button bg-blue-700"> <?php echo app('translator')->get('Save'); ?> </button>
                        </div>
                    </form>
                </div>

            </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/qotq51m9rkvr/public_html/core/resources/views/templates/basic/user/settings/general_setting.blade.php ENDPATH**/ ?>