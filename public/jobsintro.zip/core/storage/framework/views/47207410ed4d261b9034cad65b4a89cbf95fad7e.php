
<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('templates.basic.auth.password-update')->html();
} elseif ($_instance->childHasBeenRendered('2BYZvEt')) {
    $componentId = $_instance->getRenderedChildComponentId('2BYZvEt');
    $componentTag = $_instance->getRenderedChildComponentTagName('2BYZvEt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2BYZvEt');
} else {
    $response = \Livewire\Livewire::mount('templates.basic.auth.password-update');
    $html = $response->html();
    $_instance->logRenderedChild('2BYZvEt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>


<script>
    $(document).ready(function () {
        $("#new_password").click(function () {
            var current_password = $("#current_password").val();
            //alert(current_password);
            $.ajax({
                type:'get',
                url:'<?php echo e(route("user.setting.ckeckPass")); ?>',
                data:{current_password:current_password},
                success:function(resp){
                    //alert(resp);
                    if (resp == "false") {
                        $("#pwdChk").html("<font color='red'>Current Password is Incorrect</font>");
                    } else if (resp == "true"){
                        $("#pwdChk").html("<font color='green'>Current Password is Correct</font>");
                    }
                },error:function(){
                    alert("Error");
                }
            });
        });
    });
</script>

<script type="text/javascript">
function passupdate(){
        var newPassword = document.getElementById("new_password").value;
        var confirmPassword = document.getElementById("password_confirm").value;
        var currentPassword = document.getElementById("current_password").value;

        if(currentPassword==""){
            document.getElementById("pwdChk").innerHTML="<font color='red'>*** Please Fill Current Password</font>";
            return false;
        }

        if(currentPassword.length < 7){
            document.getElementById("pwdChk").innerHTML="<font color='red'>*** Password length must be greater than 7 characters</font>";
            return false;
        }

        if(currentPassword.length > 20){
            document.getElementById("pwdChk").innerHTML="<font color='red'>*** Password length must be smaller than 20 characters</font>";
            return false;
        }

        if(newPassword==""){
            document.getElementById("newPwd").innerHTML="<font color='red'>*** Please Fill Password</font>";
            return false;
        }

        if(newPassword.length < 7){
            document.getElementById("newPwd").innerHTML="<font color='red'>*** Password length must be greater than 7 characters</font>";
            return false;
        }

        if(newPassword.length > 20){
            document.getElementById("newPwd").innerHTML="<font color='red'>*** Password length must be smaller than 20 characters</font>";
            return false;
        }

        if(newPassword!=confirmPassword){
            document.getElementById("newPwd").innerHTML="<font color='red'>*** Password does not match.</font>";
            return false;
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/qotq51m9rkvr/public_html/core/resources/views/templates/basic/user/settings/password_update.blade.php ENDPATH**/ ?>