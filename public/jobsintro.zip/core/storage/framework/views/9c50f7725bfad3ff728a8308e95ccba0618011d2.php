<div class="lg:w-1/3">
 
                        <nav class="responsive-nav setting-nav setting-menu"
                            uk-sticky="top:30 ; offset:80 ; media:@m  ;bottom:true; animation: uk-animation-slide-top">
                            <h4 class="mb-0 p-3 uk-visible@m hidden"> Setting Navigation </h4>
                            <ul>
                                <li class="uk-active"><a href="<?php echo e(route('user.setting.generalSetting')); ?>"> <i class="uil-cog"></i> <?php echo app('translator')->get('General Settings'); ?> </a></li>
                                <li><a href="<?php echo e(route('user.setting.profileSetting')); ?>"> <i class="uil-user"></i> <?php echo app('translator')->get('Profile'); ?> </a></li>
                                <li><a href="<?php echo e(route('user.setting.privacySetting')); ?>"> <i class="uil-usd-circle"></i> <?php echo app('translator')->get('Privacy'); ?></a></li>
                                <li><a href="<?php echo e(route('user.setting.manage.sessions')); ?>"> <i class="uil-unlock-alt"></i> <?php echo app('translator')->get('Manage Sessions'); ?> </a></li>
                                <li><a href="<?php echo e(route('user.setting.twofactor')); ?>"> <i class="uil-dollar-alt"></i> <?php echo app('translator')->get('Two Factor Authentication'); ?></a></li>
                                <li><a href="<?php echo e(route('user.setting.socialinks')); ?>"> <i class="uil-scenery"></i> <?php echo app('translator')->get('Social links'); ?></a></li>
                                <li><a href="<?php echo e(route('user.setting.notify')); ?>"> <i class="uil-shield-check"></i> Notification Settings</a></li>
                                <li><a href="#"> <i class="uil-bolt"></i> Membarship</a></li>
                                <li><a href="#"> <i class="uil-history"></i> Manage Sessions</a></li>
                                <li><a href="#"> <i class="uil-trash-alt"></i> Delete account</a></li>
                            </ul>
                        </nav>

                    </div><?php /**PATH /home/qotq51m9rkvr/public_html/core/resources/views/templates/basic/partials/setting_bar.blade.php ENDPATH**/ ?>