<div>
    <form>
         <div class="header-search-icon"> 

         </div>
         <div class="header_search"><i class="uil-search-alt"></i>
             <input id="dropdownSearch" data-dropdown-toggle="searchDropDown"  type="text" class="form-control" name="search" wire:model.debouce.350ms="search" placeholder="Search for Friends , Videos and more.." autocomplete="off">
         </form>
             <div class="header_search_dropdown <?php echo e($search != '' ? 'block' : ''); ?>" id="searchDropDown" style="<?php echo e($search != '' ? 'position: absolute; inset: 0px auto auto 0px; margin: 0px; transform: translate(0px, 54px);' : ''); ?>">

                 <h4 class="search_title"> Recently </h4>
                 <ul>
                    
                     <?php if($users && count($users) > 0): ?>

                         <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <li key=<?php echo e($loop->index); ?>> 
                                 <a href="#">
                                     <img src="<?php echo e(asset($user->avtar)); ?>" class="list-avatar">
                                     <div class="list-name"> <?php echo e($user->firstname . ' ' . $user->lastname); ?> </div>
                                 </a>
                             </li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php else: ?>
                         <li>
                             <div class="list-name"> No Result Found </div>
                         </li>
                     <?php endif; ?>
                 </ul>

             </div>
         </div>

</div>
<?php /**PATH D:\Take care\AAMGroup\jobsintroLaravel-main-2\resources\views/livewire/templates/basic/search.blade.php ENDPATH**/ ?>