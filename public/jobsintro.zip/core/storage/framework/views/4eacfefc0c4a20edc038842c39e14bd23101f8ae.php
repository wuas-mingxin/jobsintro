
<?php $__env->startSection('content'); ?>
<div class="main_content">
    <div class="mcontainer">

        

        <div class="mb-6">
            <h2 class="text-2xl font-semibold"> <?php echo e($page_title); ?> </h2>
        </div>

        <div class="bg-white lg:divide-x lg:flex lg:shadow-md rounded-md shadow lg:rounded-xl overflow-hidden lg:m-0 -mx-4">
            <?php echo $__env->make($activeTemplate . 'partials.setting_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="lg:w-2/3">

                <div class="lg:flex lg:flex-col justify-between lg:h-full">

                    <!-- form header -->
                    <div class="lg:px-10 lg:py-8 p-6">
                        <h3 class="font-bold mb-2 text-xl"><?php echo e($page_title); ?></h3>
                    </div>

                    <!-- form body -->
                    <form action="<?php echo e(route('user.setting.privacySetting.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="lg:py-8 lg:px-20 flex-1 space-y-4 p-6">

                            <div>
                                <label for="follow_privacy"> <?php echo app('translator')->get('Who can follow me?'); ?> </label>
                                <select id="follow_privacy" name="follow_privacy"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->follow_privacy == 0): ?> selected <?php endif; ?> >Everyone</option>
                                    <option value="1" <?php if($user->follow_privacy == 1): ?> selected <?php endif; ?> >People I Follow</option>
                                </select>
                            </div>

                            <div>
                                <label for="message_privacy"> <?php echo app('translator')->get('Who can messages me?'); ?> </label>
                                <select id="message_privacy" name="message_privacy"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->message_privacy == 0): ?> selected <?php endif; ?> >Everyone</option>
                                    <option value="1" <?php if($user->message_privacy == 1): ?> selected <?php endif; ?> >People I Follow</option>
                                    <option value="2" <?php if($user->message_privacy == 2): ?> selected <?php endif; ?> >No Body</option>
                                </select>
                            </div>

                            <div>
                                <label for="friend_privacy"> <?php echo app('translator')->get('Who can see my friends?'); ?> </label>
                                <select id="friend_privacy" name="friend_privacy"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->friend_privacy == 0): ?> selected <?php endif; ?> >Everyone</option>
                                    <option value="1" <?php if($user->friend_privacy == 1): ?> selected <?php endif; ?> >People I Follow</option>
                                    <option value="2" <?php if($user->friend_privacy == 2): ?> selected <?php endif; ?> >People Follow Me</option>
                                    <option value="3" <?php if($user->friend_privacy == 3): ?> selected <?php endif; ?> >No body</option>
                                </select>
                            </div>

                            <div>
                                <label for="post_privacy"> <?php echo app('translator')->get('Who can post on my timeline?'); ?> </label>
                                <select id="post_privacy" name="post_privacy"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->post_privacy == 0): ?> selected <?php endif; ?> >Everyone</option>
                                <option value="1" <?php if($user->post_privacy == 1): ?> selected <?php endif; ?> >People I Follow</option>
                                <option value="2" <?php if($user->post_privacy == 2): ?> selected <?php endif; ?> >No body</option>
                                </select>
                            </div>

                            <div>
                                <label for="birth_privacy"> <?php echo app('translator')->get('Who can see my birthday?'); ?> </label>
                                <select id="birth_privacy" name="birth_privacy"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->birth_privacy == 0): ?> selected <?php endif; ?> >Everyone</option>
                                <option value="1" <?php if($user->birth_privacy == 1): ?> selected <?php endif; ?> >People I Follow</option>
                                <option value="2" <?php if($user->birth_privacy == 2): ?> selected <?php endif; ?> >No body</option>
                                </select>
                            </div>

                            <div>
                                <label for="confirm_followers"> <?php echo app('translator')->get('Confirm request when someone follows you?'); ?> </label>
                                <select id="confirm_followers" name="confirm_followers"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->confirm_followers == 0): ?> selected <?php endif; ?> >No</option>
                                    <option value="1" <?php if($user->confirm_followers == 1): ?> selected <?php endif; ?> >Yes</option>
                                </select>
                            </div>

                            <div>
                                <label for="show_activities_privacy"> <?php echo app('translator')->get('Show my activies?'); ?> </label>
                                <select id="show_activities_privacy" name="show_activities_privacy"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->show_activities_privacy == 0): ?> selected <?php endif; ?> >No</option>
                                <option value="1" <?php if($user->show_activities_privacy == 1): ?> selected <?php endif; ?> >Yes</option>
                                </select>
                            </div>

                            <div>
                                <label for="chat_status"> <?php echo app('translator')->get('Status'); ?> </label>
                                <select id="chat_status" name="chat_status"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->status == 0): ?> selected <?php endif; ?> >Online</option>
                                    <option value="1" <?php if($user->status == 1): ?> selected <?php endif; ?> >Offline</option>
                                </select>
                            </div>

                            <div>
                                <label for="share_my_location"> <?php echo app('translator')->get('Show my location with public?'); ?> </label>
                                <select id="share_my_location" name="share_my_location"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->share_my_location == 0): ?> selected <?php endif; ?> >No</option>
                                    <option value="1" <?php if($user->share_my_location == 1): ?> selected <?php endif; ?> >Yes</option>
                                </select>
                            </div>

                            <div>
                                <label for="share_my_data"> <?php echo app('translator')->get('Allow search engines to index my profile and posts?'); ?> </label>
                                <select id="share_my_data" name="share_my_data"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->share_my_data == 0): ?> selected <?php endif; ?> >No</option>
                                    <option value="1" <?php if($user->share_my_data == 1): ?> selected <?php endif; ?> >Yes</option>
                                </select>
                            </div>

                        </div>

                        <div class="bg-gray-10 p-6 pt-0 flex justify-end space-x-3">
                            <button type="submit" class="button bg-blue-700"> <?php echo app('translator')->get('Save'); ?> </button>
                        </div>
                    </form>
                </div>

            </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make($activeTemplate . 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/qotq51m9rkvr/public_html/core/resources/views/templates/basic/user/settings/privacy.blade.php ENDPATH**/ ?>