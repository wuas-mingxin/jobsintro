
<?php $__env->startSection('content'); ?>
<div class="main_content">
    <div class="mcontainer">

        


        <div class="mb-6">
            <h2 class="text-2xl font-semibold"> <?php echo e($page_title); ?> </h2>
        </div>

        <div class="bg-white lg:divide-x lg:flex lg:shadow-md rounded-md shadow lg:rounded-xl overflow-hidden lg:m-0 -mx-4">
            <?php echo $__env->make($activeTemplate . 'partials.setting_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="lg:w-2/3">

                <div class="lg:flex lg:flex-col justify-between lg:h-full">

                    <!-- form header -->
                    <div class="lg:px-10 lg:py-8 p-6">
                        <h3 class="font-bold mb-2 text-xl"><?php echo e($page_title); ?></h3>
                    </div>

                    <!-- form body -->
                    <form action="<?php echo e(route('user.setting.profileSetting.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="lg:py-8 lg:px-20 flex-1 space-y-4 p-6">

                            <div class="line">
                                <input class="line__input" id="firstname" autocomplete="off" name="firstname" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="*Emma" value="<?php echo e($user->firstname); ?>">
                                <span for="firstname" class="line__placeholder"><?php echo app('translator')->get('First name'); ?></span>
                            </div>

                            <div class="line">
                                <input class="line__input" id="lastname" autocomplete="off" name="lastname" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="*Watson" value="<?php echo e($user->lastname); ?>">
                                <span for="lastname" class="line__placeholder"> <?php echo app('translator')->get('Last Name'); ?> </span>
                            </div>

                            <div class="line">
                                <textarea class="line__input" id="aboutme" autocomplete="off" name="aboutme" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="Write about yourself" rows="3"><?php echo e($user->about); ?></textarea>
                                <span for="aboutme" class="line__placeholder"> <?php echo app('translator')->get('About Me'); ?> </span>
                            </div>

                            <div class="line">
                                <input class="line__input" id="location" autocomplete="off" name="location" onkeyup="this.setAttribute('value', this.value);" value="<?php echo e($user->last_location_update); ?>">
                                <span for="location" class="line__placeholder"><?php echo app('translator')->get('Location'); ?> </span>
                            </div>

                            <div class="line">
                                <input class="line__input" id="school" autocomplete="off" name="school" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="Enter a school" value="<?php echo e($user->school); ?>">
                                <span for="school" class="line__placeholder"><?php echo app('translator')->get('School'); ?> </span>
                            </div>

                            <div class="line">
                                <label>Completed</label>
                                        
                                <div class="flex justify-between items-center">
                                    <div>
                                        <h4> Verified</h4>
                                    </div>
                                    <div class="switches-list -mt-8 is-large">
                                        <div class="switch-container">
                                            <label class="switch">
                                                <input type="checkbox" name="schoolcompleted" <?php if($user->school_completed == 1): ?> checked <?php endif; ?> >
                                                <span class="switch-button"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="line">
                                <input class="line__input" id="working" autocomplete="off" name="working" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="eg Apple" value="<?php echo e($user->working); ?>">
                                <span for="working" class="line__placeholder"><?php echo app('translator')->get('Working at'); ?> </span>
                            </div>

                            <div class="line">
                                <input class="line__input" id="working_link" autocomplete="off" name="working_link" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="Comlpany Website" value="<?php echo e($user->working_link); ?>">
                                <span for="working_link" class="line__placeholder"><?php echo app('translator')->get('Comlpany Website'); ?> </span>
                            </div>

                            <div class="line">
                                <input class="line__input" id="website" autocomplete="off" name="website" type="text" onkeyup="this.setAttribute('value', this.value);" placeholder="Comlpany Website" value="<?php echo e($user->website); ?>">
                                <span for="website" class="line__placeholder"><?php echo app('translator')->get('Website'); ?> </span>
                            </div>

                            <div>
                                <label for="relationship"> <?php echo app('translator')->get('Relationship'); ?> </label>
                                <select id="relationship" name="relationship"  class="shadow-none selectpicker with-border ">
                                    <option value="0" <?php if($user->relationship_id == 0): ?> selected <?php endif; ?> >None</option>
                                    <option value="1" <?php if($user->relationship_id == 1): ?> selected <?php endif; ?> >Single</option>
                                    <option value="2" <?php if($user->relationship_id == 2): ?> selected <?php endif; ?> >In a relationship</option>
                                    <option value="3" <?php if($user->relationship_id == 3): ?> selected <?php endif; ?> >Married</option>
                                    <option value="4" <?php if($user->relationship_id == 4): ?> selected <?php endif; ?> >Engaged</option>
                                </select>
                            </div>

                        </div>

                        <div class="bg-gray-10 p-6 pt-0 flex justify-end space-x-3">
                            <button class="p-2 px-4 rounded bg-gray-50 text-red-500"> <?php echo app('translator')->get('Cancel'); ?> </button>
                            <button type="submit" class="button bg-blue-700"> <?php echo app('translator')->get('Save'); ?> </button>
                        </div>
                    </form>
                </div>

            </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($activeTemplate . 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/qotq51m9rkvr/public_html/core/resources/views/templates/basic/user/settings/profile.blade.php ENDPATH**/ ?>