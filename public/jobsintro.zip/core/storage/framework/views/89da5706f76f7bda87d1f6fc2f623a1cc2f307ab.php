<div class="mb-6">
    <h2 class="text-2xl font-semibold"> <?php echo e($page_title); ?> </h2>
    <nav class="responsive-nav border-b md:m-0 -mx-4">
        <ul >
            <li><a href="<?php echo e(route('user.setting.generalSetting')); ?>" class="lg:px-2"> <?php echo app('translator')->get('General Settings'); ?></a></li>
            <li><a href="<?php echo e(route('user.setting.profileSetting')); ?>" class="lg:px-2"> <?php echo app('translator')->get('Profile'); ?></a></li>
            <li><a href="<?php echo e(route('user.setting.privacySetting')); ?>" class="lg:px-2"> <?php echo app('translator')->get('Privacy'); ?></a></li>
            <li><a href="<?php echo e(route('user.setting.manage.sessions')); ?>" class="lg:px-2"> <?php echo app('translator')->get('Manage Sessions'); ?></a></li>
            <li><a href="<?php echo e(route('user.setting.twofactor')); ?>" class="lg:px-2"> <?php echo app('translator')->get('Two Factor Authentication'); ?></a></li>
            <li><a href="<?php echo e(route('user.setting.socialinks')); ?>" class="lg:px-2"> <?php echo app('translator')->get('Social links'); ?> </a></li>
        </ul>
    </nav>
</div><?php /**PATH /home/qotq51m9rkvr/public_html/core/resources/views/templates/basic/partials/setting_header.blade.php ENDPATH**/ ?>