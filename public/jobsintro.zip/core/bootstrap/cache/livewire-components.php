<?php return array (
  'notifications' => 'App\\Http\\Livewire\\Notifications',
  'templates.basic.auth.password-update' => 'App\\Http\\Livewire\\Templates\\Basic\\Auth\\PasswordUpdate',
  'templates.basic.create-post' => 'App\\Http\\Livewire\\Templates\\Basic\\CreatePost',
  'templates.basic.guest-post' => 'App\\Http\\Livewire\\Templates\\Basic\\GuestPost',
  'templates.basic.notification-items' => 'App\\Http\\Livewire\\Templates\\Basic\\NotificationItems',
  'templates.basic.notifications' => 'App\\Http\\Livewire\\Templates\\Basic\\Notifications',
  'templates.basic.search' => 'App\\Http\\Livewire\\Templates\\Basic\\Search',
  'templates.basic.show-comments' => 'App\\Http\\Livewire\\Templates\\Basic\\ShowComments',
  'templates.basic.show-posts' => 'App\\Http\\Livewire\\Templates\\Basic\\ShowPosts',
);