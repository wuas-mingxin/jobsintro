<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WuasShareController extends Controller
{
    //
}
